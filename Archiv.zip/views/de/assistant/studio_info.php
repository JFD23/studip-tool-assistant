<? if ($view === 'selfrecording'): ?>

<h2>Aufzeichnungsmöglichkeiten im PELA</h2>

<iframe src="https://media.hs-wismar.de/static/mh_default_org/engage-player/77bff774-560c-44e2-9f8c-cc4745e7877b/2fc56281-6479-48f3-b547-b6b57f1b0d61/20190711_Export_PELA_Web_Quali.mp4" name="Paella Player"  allowfullscreen="" width="570" height="321" frameborder="0"></iframe>


<? endif ?>
