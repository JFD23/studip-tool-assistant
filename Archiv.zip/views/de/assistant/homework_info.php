<? if ($view === 'howto'): ?>
    <h2>Einfache Abgaben: Hausaufgabenordner</h2>
    <div style="float:right;margin-left:10px;">
        <p>
            <img src="<?= $plugin->getPluginURL() ?>/assets/studip-hausaufgaben-aktionen.jpg" width="240">
        </p>
        <p>
            <img src="<?= $plugin->getPluginURL() ?>/assets/studip-hausaufgaben-typ.jpg" width="240">
        </p>

    </div>
    <p>
        Auf der Seite "Dateien" klicken Sie links in der Navigation auf "Neuer Ordner".
    </p>
    <p>
        Anschließend geben Sie oben einen passenden Namen für den Ordner ein.
        Weiter unten wählen Sie "Ordner für Hausarbeiten" aus und bestätigen mit "Erstellen".
    </p>
<? endif ?>
